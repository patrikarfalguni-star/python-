#Q1
name=input("Enter your name:")
age=int(input("Enter your age:"))
print("hello",name,",you are",age,"years old")
#Q2
a=int(input("Enter breadth of rectangle:"))
b=int(input("Enter depth of rectangle:"))
c=(a+b)*2
print("perimeter of rectangle:",c)
#Q3
a=int(input("Enter Km:"))
b=a*1000
c=b*100
print("In meter=",b,("m"))
print("In centimeters=",c,("cm"))
#Q4
a=int(input("Price of product 1:"))
b=int(input("Price of product 2:"))      
c=int(input("Price of product 3:"))
d=a+b+c
print("total price of all products are=",d )
